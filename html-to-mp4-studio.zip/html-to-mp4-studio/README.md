# HTML to MP4 Studio

Aplikasi web statis untuk memasukkan HTML, melihat preview, merekam frame ke WebM, lalu mengonversinya menjadi MP4 langsung di browser.

## File
- `index.html` — struktur aplikasi
- `style.css` — tampilan dark mode responsif
- `script.js` — preview, canvas capture, MediaRecorder, dan FFmpeg.wasm

## Deploy ke GitHub Pages
1. Buat repository GitHub bernama `html-to-mp4-studio`.
2. Upload ketiga file (`index.html`, `style.css`, `script.js`) ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main`, folder `/ (root)`, lalu tekan **Save**.
6. Tunggu proses deploy selesai. URL akan berbentuk `https://USERNAME.github.io/html-to-mp4-studio/`.

## Cara menggunakan
1. Buka situs melalui Chrome/Chromium terbaru.
2. Tempel satu dokumen HTML lengkap ke editor. CSS dan JavaScript boleh ditulis di dalam dokumen tersebut menggunakan tag `<style>` dan `<script>`.
3. Tekan **Perbarui preview**.
4. Atur resolusi, rasio, FPS, dan durasi.
5. Tekan **Render MP4** dan tunggu proses selesai.
6. Tekan **Download MP4**.

## Catatan teknis dan batasan
- Aplikasi memakai `html2canvas` untuk menggambar ulang tampilan DOM ke canvas, `MediaRecorder` untuk merekam canvas menjadi WebM, dan `FFmpeg.wasm` untuk mengonversi WebM ke MP4.
- Render frame dilakukan berurutan. Ini bukan perekaman real-time yang presisi; durasi proses render bisa lebih lama daripada durasi video.
- CSS dan JavaScript pada preview sederhana dapat direkam, tetapi animasi yang sangat cepat, WebGL/canvas internal, video, audio, iframe lintas domain, dan gambar eksternal dapat tidak tertangkap sempurna.
- Browser dapat membatasi memori dan performa. Mulai dengan 480p/720p, 24/30 FPS, dan durasi pendek. 1080p atau 60 FPS berpotensi gagal di ponsel.
- MP4 memerlukan pengunduhan FFmpeg WebAssembly dari CDN saat pertama kali digunakan. Koneksi internet dibutuhkan untuk memuat library.
- Kode yang ditempel dijalankan di iframe sandbox. Jangan tempel kode dari sumber yang tidak dipercaya.
- File hasil berada di memori browser sampai diunduh. Jangan menutup tab sebelum mengunduh.
- Tidak ada server atau penyimpanan cloud pada versi ini.
